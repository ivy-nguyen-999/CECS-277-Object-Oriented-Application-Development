package cecs277DemoVisitorPattern;

public enum GameRating {
	EARLY_CHILDHOOD, EVERYONE, TEEN, MATURE, ADULTS_ONLY, RATING_PENDING
}