package cecs277DemoVisitorPattern;

public enum GameGenre {
	PERSONAL_COMBAT, ROAD_RAGE, SCIENCE_FICTION, SIMULATION, HORROR
}