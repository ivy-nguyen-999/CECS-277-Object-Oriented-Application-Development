package cecs277DemoVisitorPattern;

public enum MovieGenre {
	ACTION, ADVENTURE, COMEDY, CRIME, DRAMA, HISTORICAL, HORROR, MUSICAL, SCI_FI, WAR, WESTERN
}